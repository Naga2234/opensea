from blur_moralis.dashboard.app import app

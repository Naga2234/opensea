PRO‑SAFE v2.6 with Moralis. Run start.command → http://127.0.0.1:8000/.
